<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pagina inicial</title>
</head>
<body>
     <button><a href="exercicio1.php">exercicio 1</a></button> <br>  
     <button><a href="exercicio2.php">exercicio 2</a></button> <br>
     <button><a href="exercicio3.php">exercicio 3</a></button> <br> 
     <button><a href="exercicio4.php">exercicio 4</a></button> <br>  
     <button><a href="exercicio5.php">exercicio 5</a></button> <br> 
     <button><a href="exercicio6.php">exercicio 6</a></button>  <br>
     <button><a href="exercicio7.php">exercicio 7</a></button>  <br>
     <button><a href="exercicio8.php">exercicio 8</a></button>  <br>
     <button><a href="exercicio9.php">exercicio 9</a></button>  <br>
     <button><a href="exercicio10.php">exercicio 10</a></button> <br>
     <button><a href="exercicio11.php">exercicio 11</a></button> <br>
     <button><a href="exercicio12.php">exercicio 12</a></button> <br>
     <button><a href="exercicio13.php">exercicio 13</a></button> <br> 
     <button><a href="exercicio14.php">exercicio 14</a></button> <br>
     <button><a href="exercicio15.php">exercicio 15</a></button> <br>
     <button><a href="exercicio16.php">exercicio 16</a></button> <br>
     <button><a href="exercicio17.php">exercicio 17</a></button> <br>
     <button><a href="exercicio18.php">exercicio 18</a></button> <br>
     <button><a href="exercicio19.php">exercicio 19</a></button> <br>  
     <button><a href="exercicio20.php">exercicio 20</a></button> <br>
     <button><a href="exercicio21.php">exercicio 21</a></button> <br>
     <button><a href="exercicio22.php">exercicio 22</a></button> <br>
     <button><a href="exercicio23.php">exercicio 23</a></button> <br>
     <button><a href="exercicio24.php">exercicio 24</a></button> <br>
     <button><a href="exercicio25.php">exercicio 25</a></button> <br>
     <button><a href="exercicio26.php">exercicio 26</a></button> <br>

     <!--LISTA 2-->

     <br>   LISTA 2  <br>
      
     <button><a href="exercicio1PT2.php">exercicio 1PT2</a></button> <br>
     <button><a href="exercicio2PT2.php">exercicio 2PT2</a></button> <br>
     <button><a href="exercicio3PT2.php">exercicio 3PT2</a></button> <br>
     <button><a href="exercicio4PT2.php">exercicio 4PT2</a></button> <br>
     <button><a href="exercicio5PT2.php">exercicio 5PT2</a></button> <br>
     <button><a href="exercicio6PT2.php">exercicio 6PT2</a></button> <br>
     <button><a href="exercicio7PT2.php">exercicio 7PT2</a></button> <br>
     <button><a href="exercicio8PT2.php">exercicio 8PT2</a></button> <br>
     <button><a href="exercicio9PT2.php">exercicio 9PT2</a></button> <br>
     <button><a href="exercicio10PT2.php">exercicio 10PT2</a></button> <br>
     <button><a href="exercicio11PT2.php">exercicio 11PT2</a></button> <br>
     <button><a href="exercicio12PT2.php">exercicio 12PT2</a></button> <br>
     <button><a href="exercicio13PT2.php">exercicio 13PT2</a></button> <br>
     <button><a href="exercicio14PT2.php">exercicio 14PT2</a></button> <br>
     <button><a href="exercicio15PT2.php">exercicio 15PT2</a></button> <br>
     <button><a href="exercicio16PT2.php">exercicio 16PT2</a></button> <br>
     <button><a href="exercicio17PT2.php">exercicio 17PT2</a></button> <br>
     <button><a href="exercicio18PT2.php">exercicio 18PT2</a></button> <br>
     <button><a href="exercicio19PT2.php">exercicio 19PT2</a></button> <br>
     <button><a href="exercicio20PT2.php">exercicio 20PT2</a></button> <br>
     <button><a href="exercicio21PT2.php">exercicio 21PT2</a></button> <br>
     <button><a href="exercicio22PT2.php">exercicio 22PT2</a></button> <br>
     <button><a href="exercicio23PT2.php">exercicio 23PT2</a></button> <br>
     <button><a href="exercicio24PT2.php">exercicio 24PT2</a></button> <br>
     <button><a href="exercicio25PT2.php">exercicio 25PT2</a></button> <br>
     <button><a href="exercicio26PT2.php">exercicio 26PT2</a></button> <br>
     <button><a href="exercicio27PT2.php">exercicio 27PT2</a></button> <br>
     <button><a href="exercicio28PT2.php">exercicio 28PT2</a></button> <br>
     <button><a href="exercicio29PT2.php">exercicio 29PT2</a></button> <br>
     



</body>
</html>